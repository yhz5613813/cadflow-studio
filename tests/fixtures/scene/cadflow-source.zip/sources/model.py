# Embedded source mapping fixture; not an executable CAD build.
size = 1000
body = make_tetrahedron(size)
